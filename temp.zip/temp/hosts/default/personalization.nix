{ lib, ... }: {
  programs.dconf.profiles.gdm.databases = [{
    settings = {
      "org/gnome/desktop/interface" = {
        clock-show-seconds = true;
        clock-show-weekday = true;
      };
      "org/gnome/desktop/peripherals/mouse" = {
        accel-profile = "flat";
        left-handed = true;
      };
      "org/gnome/desktop/session" = {
        idle-delay = lib.gvariant.mkUint32 60;  # a minute
      };
      "org/gnome/settings-daemon/plugins/power" = {
        power-button-action = "suspend";
        sleep-inactive-ac-timeout = lib.gvariant.mkInt32 300;  # 5 minutes
        sleep-inactive-battery-timeout = lib.gvariant.mkInt32 90;  # a minute and a half
      };
    };
  }];
}
