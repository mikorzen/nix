{ pkgs, ... }: {
  imports = [
    ./software/audio.nix
    ./software/flatpak.nix
    ./software/gnome.nix
  ];

  environment.systemPackages = with pkgs; [
    dconf-editor
    ghostty         # terminal
    gnome-firmware  # firmware updates
  ];

  programs = {
    command-not-found.enable = true; 
    fish.enable = true;    # shell
    git.enable = true;     # version control (that's crazy)
    nh.enable = true;      # nix helper  
  };

  services = {
    fwupd.enable = true;     # firmware updates
    printing.enable = true;  # printing
  };
}
